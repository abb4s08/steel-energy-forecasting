Winner to Steal — Steel energy forecasting ensemble.

Models: direct CatBoost, XGBoost, and change-target CatBoost.
Weights: 48.75%, 26.25%, and 25.00% respectively.

Windows instructions:
1. Install Python 3.10 to 3.12.
2. Open Command Prompt in this extracted folder.
3. Run: pip install -r requirements.txt
4. Put test.csv in this folder.
5. Run: python inference.py --input test.csv --output predictions.csv

The supplied test.csv must include the same current-interval telemetry columns
as training data, including Usage_kWh, but does not need the target column.

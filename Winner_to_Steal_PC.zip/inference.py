"""Run the Winner to Steal ensemble on a test CSV.

Example (Windows):
    python inference.py --input test.csv --output predictions.csv
"""

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from catboost import CatBoostRegressor
from xgboost import XGBRegressor


PACKAGE = Path(__file__).resolve().parent
RAW_COLUMNS = [
    "date", "Usage_kWh", "Lagging_Current_Reactive.Power_kVarh",
    "Leading_Current_Reactive_Power_kVarh", "CO2(tCO2)",
    "Lagging_Current_Power_Factor", "Leading_Current_Power_Factor", "NSM",
    "WeekStatus", "Day_of_week", "Load_Type",
]


def add_features(history_df, future_df, features):
    history = history_df[RAW_COLUMNS].tail(672).copy()
    history["_source"] = "history"
    future = future_df[RAW_COLUMNS].copy()
    future["_source"] = "future"
    data = pd.concat([history, future], ignore_index=True)
    data["date"] = pd.to_datetime(data["date"], format="mixed", dayfirst=True)
    data = data.sort_values("date").reset_index(drop=True)

    data["hour"] = data["date"].dt.hour
    data["minute"] = data["date"].dt.minute
    data["month"] = data["date"].dt.month
    data["day_number"] = data["date"].dt.dayofweek
    data["is_weekend"] = (data["day_number"] >= 5).astype(int)
    data["time_sin"] = np.sin(2 * np.pi * data["NSM"] / 86400)
    data["time_cos"] = np.cos(2 * np.pi * data["NSM"] / 86400)
    data["reactive_power_total"] = (
        data["Lagging_Current_Reactive.Power_kVarh"]
        + data["Leading_Current_Reactive_Power_kVarh"]
    )
    data["power_factor_difference"] = (
        data["Lagging_Current_Power_Factor"]
        - data["Leading_Current_Power_Factor"]
    )
    for lag in [1, 2, 4, 8, 16, 24, 96, 192, 672]:
        data[f"usage_lag_{lag}"] = data["Usage_kWh"].shift(lag)
    for window in [4, 16, 96, 672]:
        data[f"usage_mean_{window}"] = data["Usage_kWh"].rolling(window).mean()
        data[f"usage_std_{window}"] = data["Usage_kWh"].rolling(window).std()
    data["usage_change_1"] = data["Usage_kWh"].diff(1)
    data["usage_change_4"] = data["Usage_kWh"].diff(4)

    rows = data.loc[data["_source"].eq("future")].copy()
    if rows[features].isna().any().any():
        raise ValueError("Input needs 672 previous 15-minute history rows.")
    return rows


def main(input_path, output_path):
    with (PACKAGE / "steel_best_model_metadata.json").open() as file:
        metadata = json.load(file)
    features = metadata["features"]

    catboost = CatBoostRegressor()
    catboost.load_model(PACKAGE / "steel_catboost_energy.cbm")
    xgboost = XGBRegressor()
    xgboost.load_model(PACKAGE / "steel_xgboost_energy.json")
    change_model = CatBoostRegressor()
    change_model.load_model(PACKAGE / "steel_change_catboost_energy.cbm")
    preprocessor = joblib.load(PACKAGE / "steel_energy_preprocessor.joblib")

    history = pd.read_csv(PACKAGE / "steel_history_context.csv")
    future = pd.read_csv(input_path)
    missing = sorted(set(RAW_COLUMNS) - set(future.columns))
    if missing:
        raise ValueError("Input CSV is missing columns: " + ", ".join(missing))

    rows = add_features(history, future, features)
    cat_prediction = catboost.predict(rows[features])
    xgb_prediction = xgboost.predict(preprocessor.transform(rows[features]))
    change_prediction = rows["Usage_kWh"].to_numpy() + change_model.predict(rows[features])
    prediction = (
        metadata["direct_catboost_weight"] * cat_prediction
        + metadata["xgboost_weight"] * xgb_prediction
        + metadata["change_catboost_weight"] * change_prediction
    )

    output = pd.DataFrame({
        "forecast_for": rows["date"] + pd.Timedelta(minutes=15),
        "predicted_next_interval_Usage_kWh": prediction,
    })
    output.to_csv(output_path, index=False)
    print(f"Created {len(output):,} predictions: {output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to test.csv")
    parser.add_argument("--output", default="predictions.csv", help="Output CSV path")
    arguments = parser.parse_args()
    main(arguments.input, arguments.output)
